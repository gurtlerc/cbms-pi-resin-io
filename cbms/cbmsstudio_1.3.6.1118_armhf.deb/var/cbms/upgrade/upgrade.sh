#!/bin/sh

RESULT=1
VERSION=$1

echo "Upgrading platform version $VERSION"


RESULT=0


exit $RESULT
